<?php
$API = array(
    'QueryDatabase'=>array(
        'methods'=>array(
            'getResults'=>array(
                'len'=>1
            )
        )
    )
);